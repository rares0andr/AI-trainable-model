import numpy as np
import pandas as pd
#pentru manipularea datelor
from functools import partial

# fixez o valoare globală pentru random generator
np.random.seed(42)

from imblearn.pipeline import Pipeline
from imblearn.under_sampling import RandomUnderSampler
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.svm import SVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import (
    GridSearchCV, StratifiedKFold, cross_val_predict
)
#toate pentru pipeline
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    accuracy_score,
    precision_recall_curve
)
#pentru rezultate
# ——————————————————————————————————————————
# 1. Încarc datele de antrenament (toate cele 5822 exemple)
data     = pd.read_csv("TICDATA2000.txt", delimiter='\t', header=None)
X_train  = data.iloc[:, :-1].values
y_train  = data.iloc[:,  -1].values   # 5474 de ‘0’ și 348 de ‘1’

# 2. Construire pipeline
pipe = Pipeline([
    ('scale',      StandardScaler()),
    #centreaza la 0 si scaleaza la deviatie 1
    ('select',     SelectKBest(partial(mutual_info_classif, random_state=42),k=80)),
    #pastrez cele mai relevante 80 de caracteristici ale fiecarui client
    ('undersample', RandomUnderSampler(sampling_strategy=1.0, random_state=42)),
    #sampling_strategy=1.0 reduce clasa majoritara a.i. nr de oameni cu polita aprox= nr oameni fara polita
    ('svm',        CalibratedClassifierCV(estimator=SVC(class_weight='balanced', probability=True, random_state=42),
                                          cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42)))
    #k=5 folduri de impartire a datelor de antrenament pentru det hiperparametrilor
])

# 3. Definim grila de hiperparametri pentru SVM 
C_range     = [2 ** i for i in range(-5, 8, 2)]
gamma_range = [2 ** i for i in range(-15, 4, 2)]
#liste cu parametrii C si gamma de variat
param_grid  = {
    'svm__estimator__C':      C_range,
    'svm__estimator__gamma':  gamma_range,
    'svm__estimator__kernel': ['rbf']
}

# 4. GridSearchCV optimizat pe F1
grid = GridSearchCV(
    estimator=pipe,
    param_grid=param_grid,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    scoring='f1',
    n_jobs=-1,
    verbose=1
)
grid.fit(X_train, y_train)

best_pipe = grid.best_estimator_
print("Best params:", grid.best_params_)
print("Best CV F1-score:", grid.best_score_)

# 5. Threshold tuning
cv_preds = cross_val_predict(
    best_pipe, X_train, y_train,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    method='predict_proba'
)
y_proba_cv = cv_preds[:, 1]
prec, rec, thr = precision_recall_curve(y_train, y_proba_cv)

#evităm diviziunea prin zero
prec, rec = prec[:-1], rec[:-1]
with np.errstate(divide='ignore', invalid='ignore'):
    f1_scores = np.where(
        (prec + rec) > 0,
        2 * prec * rec / (prec + rec),
        0.0
    )

best_idx = np.argmax(f1_scores)
best_thr = thr[best_idx]
print(f"Optimal threshold for F1₁: {best_thr:.4f} (F1 = {f1_scores[best_idx]:.4f})")

# 6. Reantrenez modelul final pe întregul set de antrenament
best_pipe.fit(X_train, y_train)

# 7. Evaluare finală pe TICDATA2000
y_proba_train = best_pipe.predict_proba(X_train)[:, 1]
y_pred_train  = (y_proba_train >= best_thr).astype(int)

print("\n=== Raport final pe TICDATA2000 ===")
print("Accuracy:", accuracy_score(y_train, y_pred_train))
print("Confusion Matrix:\n", confusion_matrix(y_train, y_pred_train))
print("Classification Report:\n", classification_report(y_train, y_pred_train))

# 8. Încarcă setul de evaluare și generează predicții
eval_data    = pd.read_csv("TICEVAL2000.txt", delimiter='\t', header=None)
X_eval       = eval_data.values
y_proba_eval = best_pipe.predict_proba(X_eval)[:, 1]
y_pred_eval  = (y_proba_eval >= best_thr).astype(int)

# 9. Salvează predicțiile în fișier
np.savetxt("predictii.txt", y_pred_eval, fmt='%d')

# 10. Compară cu rezultatele concrete și afișează metricile
y_true_eval = pd.read_csv("TICTGTS2000.txt", header=None).iloc[:, 0].values

print("\n=== Raport final pe TICEVAL2000 ===")
print("Accuracy:", accuracy_score(y_true_eval, y_pred_eval))
print("Confusion Matrix:\n", confusion_matrix(y_true_eval, y_pred_eval))
print("Classification Report:\n", classification_report(y_true_eval, y_pred_eval))
